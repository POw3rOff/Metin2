Search and delete this:

	//m_map_stMobile.erase(account);
