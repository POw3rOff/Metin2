Search and delete this:

	void MessengerMobile(const char* c_pData);
