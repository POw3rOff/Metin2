Search and delete this:

	Set(HEADER_GG_MESSENGER_MOBILE, sizeof(TPacketGGMessengerMobile), "MessengerMobile");
