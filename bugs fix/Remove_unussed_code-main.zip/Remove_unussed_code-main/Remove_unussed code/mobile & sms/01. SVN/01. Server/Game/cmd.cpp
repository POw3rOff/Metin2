Search and delete this:

ACMD(do_mobile);
ACMD(do_mobile_auth);