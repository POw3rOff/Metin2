Search and delete this:

	std::string m_stMobile;
	char m_szMobileAuth[5];