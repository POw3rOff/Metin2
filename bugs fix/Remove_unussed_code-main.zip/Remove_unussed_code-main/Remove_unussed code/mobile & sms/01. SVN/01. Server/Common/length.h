Search and remove this:

	SMS_MAX_LEN = 80,
	MOBILE_MAX_LEN = 32,