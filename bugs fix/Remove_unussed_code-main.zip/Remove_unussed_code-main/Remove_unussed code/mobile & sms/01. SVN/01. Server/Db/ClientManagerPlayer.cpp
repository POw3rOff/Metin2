Search and delete this:

			"mobile, "

Search and delete this:

	if (row[col])
	{
		strlcpy(pkTab->szMobile, row[col], sizeof(pkTab->szMobile));
	}

	col++;