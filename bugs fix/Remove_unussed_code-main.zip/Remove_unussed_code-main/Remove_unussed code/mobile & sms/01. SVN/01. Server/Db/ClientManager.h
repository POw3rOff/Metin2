Search and remove this:

	void QUERY_SMS(CPeer* pkPeer, TPacketGDSMS* p);
