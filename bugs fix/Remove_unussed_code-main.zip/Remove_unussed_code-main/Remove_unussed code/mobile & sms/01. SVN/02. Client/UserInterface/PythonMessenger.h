Search and delete:

		void SetMobile(const char * c_szKey, BYTE byState);
