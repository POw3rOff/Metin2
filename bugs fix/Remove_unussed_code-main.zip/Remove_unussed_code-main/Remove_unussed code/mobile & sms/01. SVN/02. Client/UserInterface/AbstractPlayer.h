Search and delete:

		virtual void SetMobileFlag(BOOL bFlag) = 0;
