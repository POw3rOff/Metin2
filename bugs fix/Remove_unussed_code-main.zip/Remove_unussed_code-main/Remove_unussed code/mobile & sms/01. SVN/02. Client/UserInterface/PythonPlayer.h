Search and delete:

		// Mobile
		void	SetMobileFlag(BOOL bFlag);
		BOOL	HasMobilePhoneNumber();

Search and delete:

		// Mobile
		BOOL					m_bMobileFlag;