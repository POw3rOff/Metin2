Search and delete:

	bool SendMobileMessagePacket(const char* name, const char* c_szChat);
