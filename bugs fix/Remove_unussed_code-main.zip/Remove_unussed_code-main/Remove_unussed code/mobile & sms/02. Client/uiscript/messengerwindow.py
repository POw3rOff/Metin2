Search and delete:

			{
				"name" : "MobileButton",
				"type" : "button",

				"x" : BUTTON_START_X_POS + BUTTON_X_STEP*3,
				"y" : 30,
				"horizontal_align" : "center",
				"vertical_align" : "bottom",
				"tooltip_text" : uiScriptLocale.MESSENGER_MOBILE,
				"tooltip_x" : 0,
				"tooltip_y" : 35,

				"default_image" : "d:/ymir work/ui/game/windows/messenger_mobile_01.sub",
				"over_image" : "d:/ymir work/ui/game/windows/messenger_mobile_02.sub",
				"down_image" : "d:/ymir work/ui/game/windows/messenger_mobile_03.sub",
				"disable_image" : "d:/ymir work/ui/game/windows/messenger_mobile_04.sub",
			},

Search and delete:

			{
				"name" : "MobileButton",
				"type" : "button",

				"x" : BUTTON_START_X_POS + BUTTON_X_STEP*2,
				"y" : 30,
				"horizontal_align" : "center",
				"vertical_align" : "bottom",
				"tooltip_text" : uiScriptLocale.MESSENGER_MOBILE,
				"tooltip_x" : 0,
				"tooltip_y" : 35,

				"default_image" : "d:/ymir work/ui/game/windows/messenger_mobile_01.sub",
				"over_image" : "d:/ymir work/ui/game/windows/messenger_mobile_02.sub",
				"down_image" : "d:/ymir work/ui/game/windows/messenger_mobile_03.sub",
				"disable_image" : "d:/ymir work/ui/game/windows/messenger_mobile_04.sub",
			},