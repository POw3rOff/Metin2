Search this and delete:

LPCLIENT_DESC g_TeenDesc = NULL;

Search this and delete:

	else if (desc == g_TeenDesc)
	{
		return "g_TeenDesc";
	}

Search this and delete:

	case PHASE_TEEN:
		m_inputTeen.SetStep(0);
		m_pInputProcessor = &m_inputTeen;
		break;