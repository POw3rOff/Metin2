Search this and delete:

#include "../../common/teen_packet.h"
