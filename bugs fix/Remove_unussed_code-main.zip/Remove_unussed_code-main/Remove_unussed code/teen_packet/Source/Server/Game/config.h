Search this and delete:

extern char teen_addr[ADDRESS_MAX_LEN + 1];
extern WORD teen_port;