Search this and delete:

	CInputTeen m_inputTeen;

and delete this too:

extern LPCLIENT_DESC g_TeenDesc;
