Open game/src/MakeFile and delete passpod.cpp

Open game/src/ folder and delete passpod.cpp + passpod.h