search and delete this:

		bool SendNEWCIBNPasspodAnswerPacket(const char * answer);

		bool __AuthState_RecvNEWCIBNPasspodRequest();