search and delete this:

	bool SendNEWCIBNPasspodAnswerPacket(const char* answer);

and this:

	bool __RecvNEWCIBNPasspodRequestPacket();
	bool __RecvNEWCIBNPasspodFailurePacket();
	
