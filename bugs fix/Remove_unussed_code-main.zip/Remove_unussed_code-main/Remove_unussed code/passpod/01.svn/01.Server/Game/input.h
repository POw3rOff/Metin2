search and delete this:

	void PasspodAnswer(LPDESC d, const char* c_pData);