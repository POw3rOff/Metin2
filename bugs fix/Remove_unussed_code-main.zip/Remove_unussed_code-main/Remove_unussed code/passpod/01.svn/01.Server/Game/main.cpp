search and delete this:

#include "passpod.h"

and this:

	CPasspod passpod;