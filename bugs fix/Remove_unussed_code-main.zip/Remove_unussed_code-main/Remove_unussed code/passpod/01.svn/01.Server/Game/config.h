search and delete:

extern char passpod_addr[ADDRESS_MAX_LEN + 1];
extern WORD passpod_port;