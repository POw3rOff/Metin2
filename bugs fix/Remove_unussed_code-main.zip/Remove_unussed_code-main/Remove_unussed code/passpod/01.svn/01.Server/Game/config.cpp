search and delete:

bool g_bNoPasspod = false;