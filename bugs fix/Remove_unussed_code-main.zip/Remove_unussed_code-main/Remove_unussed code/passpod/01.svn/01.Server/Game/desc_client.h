delete this:

extern LPCLIENT_DESC g_PasspodDesc;