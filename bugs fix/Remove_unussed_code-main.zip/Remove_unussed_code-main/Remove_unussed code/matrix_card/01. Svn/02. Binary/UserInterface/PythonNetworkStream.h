Search and delete:

	bool SendChinaMatrixCardPacket(const char* c_szMatrixCardString);
	bool SendRunupMatrixAnswerPacket(const char* c_szMatrixCardString);

search and delete:

	bool __RecvChinaMatrixCardPacket();
	bool __RecvRunupMatrixQuizPacket();

