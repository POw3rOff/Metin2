search and delete this:

		bool SendChinaMatrixCardPacket(const char * c_szMatrixCardString);
		bool SendRunupMatrixCardPacket(const char * c_szMatrixCardString);

Search and delete this:

		bool __AuthState_RecvChinaMatrixCard();
		bool __AuthState_RecvRunupMatrixQuiz();