search and delete this:

#include "matrix_card.h"

search and remove this: (2x)

securitycode, 