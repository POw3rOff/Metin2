Delete matrix_card.cpp and header file from game libary.

Don't forget delete from makefile