search and delete:

enum EMatrixCard
{
	MATRIX_CODE_MAX_LEN = 192,
	MATRIX_ANSWER_MAX_LEN = 8,
};