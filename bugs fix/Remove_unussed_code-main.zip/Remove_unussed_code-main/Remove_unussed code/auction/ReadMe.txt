### SERVER_SIDE

Delete common/auction_table.h
Delete db/src/AuctionManager.cpp && AuctionManager.h <- Don't forget remove from makefile
Delete game/src/auction_manager.cpp && auction_manager.h && auction_packet.h <- Don't forget remove from makefile

### CLIENT_SIDE

Delete root/uiauction.py
Delete uiscript/ auctionwindow.py && auctionwindow_listpage.py && auctionwindow_registerpage.py && auctionwindow_uniqueauctionpage.py