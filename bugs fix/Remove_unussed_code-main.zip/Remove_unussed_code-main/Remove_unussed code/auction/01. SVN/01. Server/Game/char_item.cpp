Search and delete:

#ifdef __AUCTION__
#include "auction_manager.h"
#endif