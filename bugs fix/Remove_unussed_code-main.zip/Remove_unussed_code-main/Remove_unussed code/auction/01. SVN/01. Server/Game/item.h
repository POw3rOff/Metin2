Search and delete:

#ifdef __AUCTION__
		// °ć¸ĹŔĺ
		bool		MoveToAuction ();
		void		CopyToRawData (TPlayerItem* item);
#endif