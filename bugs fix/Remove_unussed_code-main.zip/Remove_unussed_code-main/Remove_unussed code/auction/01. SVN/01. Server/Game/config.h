Search and delete:

#ifdef __AUCTION__
extern int auction_server;
#endif