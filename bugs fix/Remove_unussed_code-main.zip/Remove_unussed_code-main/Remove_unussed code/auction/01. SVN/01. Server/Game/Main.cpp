Search and delete:

#ifdef __AUCTION__
#include "auction_manager.h"
#endif

Search and delete:

#ifdef __AUCTION__
	AuctionManager auctionManager;
#endif