Search and delete:

#ifdef __AUCTION__
#include "AuctionManager.h"
#endif

Search and delete:

#ifdef __AUCTION__
	AuctionManager auctionManager;
#endif

#ifdef __AUCTION__
	AuctionManager::instance().Initialize();
#endif