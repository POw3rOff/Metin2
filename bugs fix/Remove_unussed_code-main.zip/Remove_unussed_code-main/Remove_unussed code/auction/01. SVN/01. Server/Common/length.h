Search and delete:

	AUCTION,                    // 13