search and delete:

	// AUCTION
#ifdef __AUCTION__
	HEADER_GD_GET_AUCTION_LIST		= 135,
	HEADER_GD_COMMAND_AUCTION		= 136,
#endif

and this too:

#ifdef __AUCTION__
	HEADER_DG_AUCTION_RESULT	=	178,
#endif