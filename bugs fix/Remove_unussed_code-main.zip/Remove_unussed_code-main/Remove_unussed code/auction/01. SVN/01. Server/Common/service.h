search and delete:

//#define __AUCTION__