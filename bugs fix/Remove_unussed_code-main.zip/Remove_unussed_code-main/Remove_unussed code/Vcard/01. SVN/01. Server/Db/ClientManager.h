Search and delete this:

	// VCard
	void VCard(TPacketGDVCard* p);
	void VCardProcess();

and delete too:

	std::queue<TPacketGDVCard> m_queue_vcard;