search and delete this:

	void VCard(const char* c_pData);
