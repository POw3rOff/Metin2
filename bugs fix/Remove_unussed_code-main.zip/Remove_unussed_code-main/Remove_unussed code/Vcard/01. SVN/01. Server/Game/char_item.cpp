search and delete this:

			case 90008: // VCARD
			case 90009: // VCARD
				VCardUse(this, this, item);
				break;