search and delete:

	void VCardLog(DWORD vcard_id, DWORD x, DWORD y, const char* hostname, const char* giver_name, const char* giver_ip, const char* taker_name, const char* taker_ip);
