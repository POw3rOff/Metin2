search and delete:

#include "../../common/billing.h"

search and delete:

	SendBillingExpire(p->szLogin, BILLING_DAY, 0, NULL);