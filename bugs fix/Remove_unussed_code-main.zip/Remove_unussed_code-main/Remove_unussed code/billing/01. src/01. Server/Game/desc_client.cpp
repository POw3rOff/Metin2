search and remove:

		DBManager::instance().StopAllBilling();