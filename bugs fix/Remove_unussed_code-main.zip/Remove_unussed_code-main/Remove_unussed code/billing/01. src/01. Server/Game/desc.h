search and remove this:

	void SetBillingExpireSecond(DWORD dwSec);
	DWORD GetBillingExpireSecond();
	DWORD m_dwBillingExpireSecond;
