search and delete this:

extern BYTE g_bBilling;