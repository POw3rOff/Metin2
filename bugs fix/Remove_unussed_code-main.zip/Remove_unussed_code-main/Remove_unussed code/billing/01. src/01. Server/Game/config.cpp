search and delete this:

BYTE g_bBilling = false;

and delete too this:

		TOKEN("billing")
		{
			g_bBilling = true;
		}