search and delete:

	void BillingRepair(const char* c_pData);
	void BillingExpire(const char* c_pData);
	void BillingLogin(const char* c_pData);
	void BillingCheck(const char* c_pData);