Delete billing.h
