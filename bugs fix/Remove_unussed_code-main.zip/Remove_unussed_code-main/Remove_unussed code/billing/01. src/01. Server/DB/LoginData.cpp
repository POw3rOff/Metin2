Search this and delete:

	m_bBillType = 0;
	m_dwBillID = 0;