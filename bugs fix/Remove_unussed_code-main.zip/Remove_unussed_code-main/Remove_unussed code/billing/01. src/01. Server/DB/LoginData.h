Search this and delete:

	void		SetBillID(DWORD id) { m_dwBillID = id; }
	DWORD		GetBillID() { return m_dwBillID; }

	void		SetBillType(BYTE type) { m_bBillType = type; }
	BYTE		GetBillType() { return m_bBillType; }

Search this and delete:

	BYTE		m_bBillType;
	DWORD		m_dwBillID;