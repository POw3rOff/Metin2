Search and delete this:

#ifdef USE_OPENID
		bool __AuthState_RecvAuthSuccess_OpenID();
#endif /* USE_OPENID */
