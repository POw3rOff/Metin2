Search and delete this:

#ifdef USE_OPENID
void LocaleService_SetOpenIDAuthKey(const char *authKey);
const char*	LocaleService_GetOpenIDAuthKey();
#endif