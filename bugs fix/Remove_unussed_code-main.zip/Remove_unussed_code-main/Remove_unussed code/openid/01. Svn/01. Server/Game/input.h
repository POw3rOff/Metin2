search and delete this:

	void AuthLoginOpenID(LPDESC d, const char* c_pData);

and this:

	int auth_OpenID(const char* authKey, const char* ipAddr, char* rID);

and this:

	void LoginOpenID(LPDESC d, const char* c_pData); // 2012.07.19 OpenID : ±čżëżí
