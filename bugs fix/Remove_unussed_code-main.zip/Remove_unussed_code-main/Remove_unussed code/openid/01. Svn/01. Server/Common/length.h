search and delete this:

	OPENID_AUTHKEY_LEN = 32,