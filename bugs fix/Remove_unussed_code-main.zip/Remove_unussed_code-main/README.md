# Remove_unussed_code

The tutorial will be continuously updated.


limit_time delete (https://metin2.dev/topic/28222-collectors-topic-remove-unussed-code/?tab=comments#comment-144791)

Removed code(s)

1. Auction
2. Passpod
3. openid
4. vcard
5. blockcountry
6. limit_time
7. bill | billing
8. matrix_card
9. sms | mobile
10. libserverkey (check_server)
11. teen_packet
