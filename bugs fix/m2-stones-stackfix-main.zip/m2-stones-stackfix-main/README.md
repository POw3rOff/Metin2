# m2-stones-stackfix

Now you can stack the stones and upgrade them.
>(obviously changes the antiflags from item_proto)
