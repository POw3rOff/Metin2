cauta:
			sys_err("login phase does not handle this packet! header %d", bHeader);
			return (0);

inlocuieste return (0); cu:
#ifdef ENABLE_ANTI_PACKET_FLOOD
			return -1;
#else
			return (0);
#endif