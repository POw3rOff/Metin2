cauta :
int CInputMain::Analyze(LPDESC d, BYTE bHeader, const char * c_pData)

in functie cauta:
	if (!(ch = d->GetCharacter()))
	{
		sys_err("no character on desc");
		d->SetPhase(PHASE_CLOSE);
		return (0);

inlocuieste return (0); cu:
#ifdef ENABLE_ANTI_PACKET_FLOOD
		return -1;
#else
		return (0);
#endif



cauta tot in aceiasi functie :
	int iExtraLen = 0;

adauga deasupra:
#ifdef ENABLE_ANTI_PACKET_FLOOD
	if (bHeader != HEADER_CG_ITEM_USE)
	{
		if (thecore_pulse() > ch->GetPacketAntiFloodPulse() + PASSES_PER_SEC(1))
		{
			ch->SetPacketAntiFloodCount(0);
			ch->SetPacketAntiFloodPulse(thecore_pulse());
		}
		
		if (ch->IncreasePacketAntiFloodCount() >= 250)
		{
			sys_err("<Flood packet> name(%s) header(%u) host(%s)", ch->GetName(), bHeader, inet_ntoa(d->GetAddr().sin_addr));
			ch->GetDesc()->DelayedDisconnect(0);
			return false;
		}
	}
#endif



cauta :
int CInputDead::Analyze(LPDESC d, BYTE bHeader, const char * c_pData)

in functie cauta:
	if (!(ch = d->GetCharacter()))
	{
		sys_err("no character on desc");
		return (0);

inlocuieste return (0); cu:
#ifdef ENABLE_ANTI_PACKET_FLOOD
		return -1;
#else
		return (0);
#endif


tot in functia asta la sfarsitul ei ai:
			return (0);
inlocuieste cu:
#ifdef ENABLE_ANTI_PACKET_FLOOD
			return -1;
#else
			return (0);
#endif