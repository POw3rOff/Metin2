cauta 
			if (iExtraPacketSize < 0)

inlocuieste functia cu

			if (iExtraPacketSize < 0)
			{
#ifdef ENABLE_ANTI_PACKET_FLOOD
				sys_err("Failed to analyze header(%u) host(%s)", bHeader, inet_ntoa(lpDesc->GetAddr().sin_addr));
				lpDesc->SetPhase(PHASE_CLOSE);
#endif
				return true;
			}




cauta:
		sys_err("Handshake phase does not handle packet %d (fd %d)", bHeader, d->GetSocket());

adauga sub:
#ifdef ENABLE_ANTI_PACKET_FLOOD
		return -1;
#endif