cauta:
void CHARACTER::Initialize()

la sfarsitul functiei adauga:
#ifdef ENABLE_ANTI_PACKET_FLOOD
	m_dwPacketAntiFloodCount = 0;
	m_dwPacketAntiFloodPulse = 0;
#endif