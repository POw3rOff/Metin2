cauta:
	public:
		DWORD			GetPlayerID() const	{ return m_dwPlayerID; }

adauga deasupra:
#ifdef ENABLE_ANTI_PACKET_FLOOD
	private:
		int				m_dwPacketAntiFloodPulse;
		DWORD			m_dwPacketAntiFloodCount;
	public:
		int				GetPacketAntiFloodPulse(){return m_dwPacketAntiFloodPulse;}
		DWORD			GetPacketAntiFloodCount(){return m_dwPacketAntiFloodCount;}
		DWORD			IncreasePacketAntiFloodCount(){return ++m_dwPacketAntiFloodCount;}
		void			SetPacketAntiFloodPulse(int dwPulse){m_dwPacketAntiFloodPulse=dwPulse;}
		void			SetPacketAntiFloodCount(DWORD dwCount){m_dwPacketAntiFloodCount=dwCount;}
#endif