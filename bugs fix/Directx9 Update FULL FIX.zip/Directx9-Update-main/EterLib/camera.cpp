//arat

float fDeterminantD3DMatView = D3DXMatrixfDeterminant(&m_matView);

//değiştir

float fDeterminantD3DMatView = D3DXMatrixDeterminant(&m_matView);