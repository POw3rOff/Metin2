//arat

LPDIRECT3DTEXTURE8

//değiştir

LPDIRECT3DTEXTURE9

//arat

		D3DVIEWPORT8		m_d3dOldViewport;

		LPDIRECT3DTEXTURE8	m_lpd3dShadowTexture;
		LPDIRECT3DSURFACE8	m_lpd3dShadowSurface;
		LPDIRECT3DSURFACE8	m_lpd3dDepthSurface;

		LPDIRECT3DSURFACE8	m_lpd3dOldBackBufferSurface;
		LPDIRECT3DSURFACE8	m_lpd3dOldDepthBufferSurface;

//değiştir

		D3DVIEWPORT9		m_d3dOldViewport;

		LPDIRECT3DTEXTURE9	m_lpd3dShadowTexture;
		LPDIRECT3DSURFACE9	m_lpd3dShadowSurface;
		LPDIRECT3DSURFACE9	m_lpd3dDepthSurface;

		LPDIRECT3DSURFACE9	m_lpd3dOldBackBufferSurface;
		LPDIRECT3DSURFACE9	m_lpd3dOldDepthBufferSurface;