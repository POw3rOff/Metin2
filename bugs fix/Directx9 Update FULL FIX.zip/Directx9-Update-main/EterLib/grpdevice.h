//arat

	DWORD CreatePTStreamVertexShader();
	DWORD CreatePNTStreamVertexShader();
	DWORD CreatePNT2StreamVertexShader();
	DWORD CreateDoublePNTStreamVertexShader();

//değiştir

	LPDIRECT3DVERTEXDECLARATION9 CreatePTStreamVertexShader();
	LPDIRECT3DVERTEXDECLARATION9 CreatePNTStreamVertexShader();
	LPDIRECT3DVERTEXDECLARATION9 CreatePNT2StreamVertexShader();
	LPDIRECT3DVERTEXDECLARATION9 CreateDoublePNTStreamVertexShader();