//arat

#include <d3d8.h>
#include <d3dx8.h>

//değiştir

#include <d3d9.h>
#include <d3dx9.h>

//arat

#pragma comment(lib, "d3d8.lib")
#pragma comment(lib, "d3dx8.lib")

//değiştir

#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dx9.lib")