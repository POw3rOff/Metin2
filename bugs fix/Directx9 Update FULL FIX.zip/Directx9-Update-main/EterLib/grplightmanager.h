//arat (3 kez)

D3DLIGHT8

//değiştir (3 kez)

D3DLIGHT9