//arat (2 kez)

D3DLIGHT8

//değiştir (2 kez)

D3DLIGHT9