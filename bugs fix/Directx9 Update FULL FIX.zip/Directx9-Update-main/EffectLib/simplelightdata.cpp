//arat

void CLightData::InitializeLight(D3DLIGHT8& light)

//değiştir

void CLightData::InitializeLight(D3DLIGHT9& light)