//arat

#include <d3dx8.h>

//değiştir

#include <d3dx9.h>