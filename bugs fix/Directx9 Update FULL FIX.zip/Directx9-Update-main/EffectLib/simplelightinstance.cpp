//arat

D3DLIGHT8 Light;

//değiştir

D3DLIGHT9 Light;