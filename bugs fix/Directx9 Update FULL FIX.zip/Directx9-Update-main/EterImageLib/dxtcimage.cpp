//arat

#include <d3d.h>

//değiştir

#include <ddraw.h>