//arat

D3DLIGHT8

//değiştir

D3DLIGHT9

//arat

D3DMATERIAL8

//değiştir

D3DMATERIAL9