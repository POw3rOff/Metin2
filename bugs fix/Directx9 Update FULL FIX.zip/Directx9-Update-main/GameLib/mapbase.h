//arat

D3DLIGHT8

//değiştir

D3DLIGHT9