//arat

D3DMATERIAL8

//değiştir

D3DMATERIAL9

//arat

STATEMANAGER.RestoreVertexShader();

//değiştir

STATEMANAGER.RestoreFVF();