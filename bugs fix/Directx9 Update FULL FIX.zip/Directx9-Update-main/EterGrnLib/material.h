//arat

#include <d3d8.h>

//değiştir

#include <d3d9.h>

//arat

LPDIRECT3DTEXTURE8		GetD3DTexture(int iStage) const;

//değiştir

LPDIRECT3DTEXTURE9		GetD3DTexture(int iStage) const;