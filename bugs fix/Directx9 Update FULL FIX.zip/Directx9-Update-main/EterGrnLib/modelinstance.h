//arat

IDirect3DVertexBuffer8

//değiştir

IDirect3DVertexBuffer9