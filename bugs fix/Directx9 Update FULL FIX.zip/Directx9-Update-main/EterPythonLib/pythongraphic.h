//arat

LPDIRECT3D8

//değiştir

LPDIRECT3D9

//arat

D3DVIEWPORT8

//değiştir

D3DVIEWPORT9