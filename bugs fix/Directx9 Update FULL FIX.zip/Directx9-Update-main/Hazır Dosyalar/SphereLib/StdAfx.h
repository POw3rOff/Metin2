#pragma once

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
//#define SPHERELIB_STRICT
//#include <crtdbg.h>

#include <d3d9.h>
#include <d3dx9.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <math.h>

#include "../eterBase/StdAfx.h"
#include "../UserInterface/Locale_inc.h"
