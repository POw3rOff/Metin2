#pragma once

#if defined(CHECK_LATEST_DATA_FILES)
bool CheckLatestFiles( void );
bool CheckLatestFiles_PollEvent( void );
#endif
