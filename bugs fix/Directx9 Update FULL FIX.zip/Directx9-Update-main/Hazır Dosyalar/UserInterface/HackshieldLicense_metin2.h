#pragma once

#define METIN2HS_EXE_FILE_NAME        "metin2.bin"
#define METIN2HS_CODE                 5858
#define METIN2HS_LICENSE              "2A126BBDC6C61351124B2872"
