#pragma once

#define METIN2HS_EXE_FILE_NAME        "metin2client.bin"
#define METIN2HS_CODE                 5857
#define METIN2HS_LICENSE              "B1FECACB51BD40B919EFCDB9"
