/**********************************************************************/
/**********************************************************************/
/**********************************************************************/
CLIENSOURCE/UserInterFace/InstanceBase.cpp		OPEN

		if (IsAffect(AFFECT_SPAWN))
			__AttachEffect(EFFECT_SPAWN_APPEAR);

		FIND AND CHANGE

		/*if (IsAffect(AFFECT_SPAWN))
			__AttachEffect(EFFECT_SPAWN_APPEAR);*/
			
			

UserInterFace/InstanceBaseBattle.cpp		OPEN

	if (IsAffect(AFFECT_SPAWN))
		__AttachEffect(EFFECT_SPAWN_DISAPPEAR);

		FIND AND CHANGE


	/*if (IsAffect(AFFECT_SPAWN))
		__AttachEffect(EFFECT_SPAWN_DISAPPEAR);*/

/**********************************************************************/
/**********************************************************************/
/**********************************************************************/
/**********************************************************************/
GAMESOURCE/char_manager.cpp			OPEN

	if (pkMob->m_table.bType == CHAR_TYPE_STONE)
		bSpawnMotion = true;

		FIND AND CHANGE

	if (pkMob->m_table.bType == CHAR_TYPE_STONE)
		bSpawnMotion = false;


